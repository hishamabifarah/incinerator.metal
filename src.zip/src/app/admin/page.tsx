import type { Metadata } from "next";
import { Suspense } from "react";
import LoginContent from "./AdminContent";

export const metadata: Metadata = {
  title: "Admin login | Incinerator Metal",
  robots: { index: false, follow: false },
};

export default function AdminLoginPage() {
  return (
    <Suspense fallback={<div className="admin-shell">Loading login...</div>}>
      <LoginContent />
    </Suspense>
  );
}